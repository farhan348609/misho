<?php $this->load->view('back/meta') ?>
<?php $this->load->view('back/navbar') ?>
<?php $this->load->view('back/sidebar') ?>
  <div class="wrapper">
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1><?php echo $title ?></h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active"><?php echo $title ?></li>
        </ol>
      </section>
      <!-- Main content -->
      <section class="content">
        <!-- penampilan total record -->
        <div class="row">
          <div class='col-sm-3'>
            <div class='small-box' style="background-color:#0ba4f2; border-radius:22px; color:white;">
              <div class='inner' style="font-family:arial;"><p><b>Total Produk</b></p><center><h3 style="font-family:times new roman; font-size:30px;"> <?php echo $total_produk ?> </h3></center></div>
              <div class='icon'><i class="far fa-chart-bar"style="color:white;position: absolute;right: 0;top: 15px;font-size:45px;"></i></div>
            </div>
          </div>
          <div class='col-sm-3'>
            <div class='small-box' style="background-color:#0ba4f2; border-radius:22px; color:white;">
              <div class='inner' style="font-family:arial;"><p><b>Penghasilan</b></p><center><h3 style="font-family:times new roman;font-size:30px;"> Rp 2.000.000 </h3></center></div>
              <div class='icon'><i class="fas fa-dollar-sign" style="color:white;position: absolute;right: 0;top: 15px;font-size:45px;"></i></div>
            </div>
          </div>
          <div class='col-sm-3'>
            <div class='small-box' style="background-color:#0ba4f2; border-radius:22px; color:white;">
              <div class='inner' style="font-family:arial;"><p><b>Laba Kotor</b></p><center><h3 style="font-family:times new roman;font-size:30px;"> Rp 1.200.000 </h3></center></div>
              <div class='icon'><i class="fas fa-user-minus"style="color:white;position: absolute;right: 0;top: 15px;font-size:35px;"></i></div>
            </div>
          </div>
          <div class='col-sm-3'>
            <div class='small-box' style="background-color:#0ba4f2; border-radius:22px; color:white;">
              <div class='inner' style="font-family:arial;"><p><b>Laba Bersih</b></p><center><h3 style="font-family:times new roman;font-size:30px;"> Rp 800.000 </h3></center></div>
              <div class='icon'><i class="fas fa-user-plus"style="color:white;position: absolute;right: 0;top: 15px;font-size:35px;"></i></div>
            </div>
          </div>
        </div>


        <!-- /.chart -->
  <div class="row">
    <div class="col-sm-8">
    <div class="box" style="border-radius:20px;">
              <div class="box-header with-border">
                <h3 class="box-title"><label>Chart Penjualan</label></h3>
              </div>
              <div class="box-body">
<canvas id="grafikBatang">
<script>
var ctx = document.getElementById("grafikBatang").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["2015", "2016", "2017", "2018", "2019", "2020"],
        datasets: [{
            label: '# of Votes',
            data: [22, 19, 3, 5, 2, 3],
            backgroundColor: ["transparent"],
            borderColor: ["#0ba4f2"],
            borderWidth: 3
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
</script></canvas>
              </div>
            </div>
    </div>
    <div class="col-sm-4">
    <div class="box"style="border-radius:20px; height:60vh;">
              <div class="box-header with-border">
                <h3 class="box-title"></h3>
              </div>
              <div class="box-body">
                <script src="<?php echo base_url('assets/plugins/chartjs/Chart.min.js') ?>"></script>
                <canvas id="pie-chart" height="300"></canvas>
                <?php foreach($get_bulan as $laporan){
                  $json[] = $laporan->judul_produk;
                  $json2[] = $laporan->total_qty;
                }?>

                <script type="text/javascript">
                  new Chart(document.getElementById("pie-chart"), {
                  type: 'doughnut',
                  data: {
                    labels: <?php echo json_encode($json); ?>,
                    datasets: [{
                      backgroundColor: ["red", "#0ba4f2","green","pink","purple"],
                      data: <?php echo json_encode($json2); ?>
                    }]
                  },
                  options: {
                    maintainAspectRatio: false,
                  }
                });
                </script>
              </div>
              </div>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-4">
    <div class="box" style="border-radius:20px;">
              <div class="box-header with-border">
                <h3 class="box-title"><label>Top Produk</label></h3>
              </div>
              <div class="box-body">
<canvas id="grafikBatang"></canvas>
<script>
var ctx = document.getElementById("grafikBatang").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
</script>
              </div>
            </div>
    </div>
    <div class="col-sm-4">
    <div class="box" style="border-radius:20px;">
              <div class="box-header with-border">
                <h3 class="box-title"><label>Top Kategori</label></h3>
              </div>
              <div class="box-body">
<canvas id="grafikBatang"></canvas>
<script>
var ctx = document.getElementById("grafikBatang").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
</script>
              </div>
            </div>
    </div>
    <div class="col-sm-4">
    <div class="box" style="border-radius:20px;">
              <div class="box-header with-border">
                <h3 class="box-title"><label>Top User</label></h3>
              </div>
              <div class="box-body">
<canvas id="grafikBatang"></canvas>
<script>
var ctx = document.getElementById("grafikBatang").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
</script>
              </div>
            </div>
    </div>
  </div>
</div>


      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
    <?php $this->load->view('back/footer') ?>
  </div><!-- ./wrapper -->
  <?php $this->load->view('back/js') ?>
</body>
</html>
