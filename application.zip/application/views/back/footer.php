<footer class="main-footer no-print">
  <strong>Copyright &copy; 2021 Misho</a>.</strong> All rights reserved.
</footer>
