
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Misho - Pengelola Data Terpercaya</title>
    <link rel="icon" href="<?php echo base_url('assets_home/img/untitle.png') ?>">

    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url() ?>assets_log/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="<?php echo base_url() ?>assets_log/https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo base_url() ?>assets_log/css/sb-admin-2.min.css" rel="stylesheet">
    <?php echo $script_captcha; // javascript recaptcha ?>
</head>

<body class="">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-5 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-12">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-12"><a href="<?php echo base_url('') ?>"><img src="<?php echo base_url('assets_log/img/logo.png') ?>" style="width:10vw;  display: block;
    margin-left: auto;
    margin-right: auto;"></a>
        <div id="infoMessage"><?php echo $message;?></div>
        <?php echo form_open("admin/auth/login");?>
          <div class="form-group has-feedback">
            <?php echo form_input($identity);?>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <?php echo form_password($password);?>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-lg-12">
              <p><?php echo $captcha ?></p>
              <p>Remember Me: <?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?></p>
              <button type="submit" class="btn btn-primary btn-block btn-flat" style="background-color:#0ba4f2;">Sign In</button>
            </div><!-- /.col -->
          </div>
        </form>
        <?php echo form_close();?>
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- modal reset password -->
    <div id="pswreset" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- konten modal-->
        <div class="modal-content">
          <!-- heading modal -->
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"><b>Reset Password</b></h4>
          </div>
          <!-- body modal -->
          <div class="modal-body">
            <?php echo form_open("admin/auth/forgot_password");?>
              <div class="form-group"><label>Silahkan masukkan Username Anda</label>
                <input class="form-control" name="identity" type="text" id="identity" />
              </div>
              <button type="submit" name="submit" class="btn btn-success">Submit</button>
            <?php echo form_close() ?>
          </div>
          <!-- footer modal -->
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
                                        <hr>
                                        <a href="#!" class="btn btn-google btn-user btn-block">
                                            <i class="fab fa-google fa-fw"></i> Login with Google
                                        </a>
                                        <a href="#!" class="btn btn-facebook btn-user btn-block">
                                            <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                                        </a>
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="#!">Forgot Password?</a>
                                        <?php echo form_close();?>
                                    </div>
                                    <div class="text-center">
                                        <a class="small" href="<?php echo base_url('auth/register') ?>">Create an Account!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>assets_log/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>assets_log/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>assets_log/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets_log/js/sb-admin-2.min.js"></script>

</body>

</html>