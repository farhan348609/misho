<aside class="main-sidebar">
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image"><img src="<?php echo base_url()?>assets/images/user/<?php echo $this->session->userdata('photo').$this->session->userdata('photo_type') ?>" class="img-circle" alt="User Image"/></div>
      <div class="pull-left info">
        <p><?php echo $this->session->userdata('name'); ?></p>
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>

    <ul class="sidebar-menu">
      <li class="header">MENU UTAMA</li>
      <li <?php if($this->uri->segment(2)=="dashboard"){echo "class='active'";} ?>>
        <a href="<?php echo base_url('admin/dashboard') ?>">
          <i class="fa fa-home"></i> <span>Dashboard</span>
        </a>
      </li>
      <li <?php if($this->uri->segment(2) == "produk"){echo "class='active'";} ?>>
          <li <?php if($this->uri->segment(2) == "produk" && $this->uri->segment(3) == ""){echo "class='active'";} ?>><a href='<?php echo base_url('admin/produk') ?>'><i class='fa fa-boxes'></i><span> Produk </span> </a></li>
      </li>
      <li <?php if($this->uri->segment(2) == "kategori"){echo "class='active'";} ?>>
          <li <?php if($this->uri->segment(2) == "kategori" && $this->uri->segment(3) == ""){echo "class='active'";} ?>><a href='<?php echo base_url('admin/kategori') ?>'><i class='fa fa-circle-o'></i> <span> Kategori </span> </a></li>
      </li>
      <li <?php if($this->uri->segment(2)=="laporan"){echo "class='active'";} ?>>
        <a href="#!">
          <i class="fa fa-file"></i> <span>Laporan</span>
        </a>
      </li>
      <li <?php if($this->uri->segment(2) == "kontak"){echo "class='active'";} ?>>
          <li <?php if($this->uri->segment(2) == "kontak" && $this->uri->segment(3) == ""){echo "class='active'";} ?>><a href='<?php echo base_url('admin/kontak') ?>'><i class="fa fa-id-badge"></i> <span> Kontak </span> </a></li>
      </li>
      <li><a href='<?php echo base_url() ?>admin/company/update/1'> <i class="fa fa-building"></i> <span>Perusahaan</span> </a> </li>
      <li class='treeview'>
        <a href='<?php $user_id = $this->session->userdata('user_id'); echo base_url('admin/auth/edit_user/'.$user_id.'') ?>'>
        <i class="fa fa-edit"></i><span> Edit Akun </span>
        </a>
      </li>
      <?php if ($this->ion_auth->is_superadmin()): ?>
      <?php endif ?>
      <li> <a href='<?php echo base_url() ?>admin/auth/logout'> <i class="fa fa-sign-out"></i> <span>Logout</span> </a> </li>
    </ul>

  </section>
</aside>
