<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $title;?></title>
    <meta charset="UTF-8">
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="<?php echo base_url('assets/template/backend/')?>bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- FontAwesome 4.3.0 -->
    <link href="<?php echo base_url('assets/plugins/')?>font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Jquery -->
    <script src="<?php echo base_url('assets/plugins/')?>jquery/jquery-3.3.1.js"></script>
    <!-- Theme style -->
    <link href="<?php echo base_url('assets/template/backend/')?>dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
    <link href="<?php echo base_url('assets/template/backend/')?>dist/css/skins/skin-black-light.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/Chartjs/Chart.min.css">
<script type="text/javascript" src="<?php echo base_url() ?>assets/Chartjs/Chart.min.js"> </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.min.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo base_url('assets/images/fav.png') ?>" />
    <script src="https://kit.fontawesome.com/04b62e6f1b.js" crossorigin="anonymous"></script>
    <title>Misho - Pengelola Data Terpercaya</title>
    <link rel="icon" href="<?php echo base_url('assets_home/img/untitle.png') ?>">
  </head>
  <body class="skin-black-light sidebar-mini">
