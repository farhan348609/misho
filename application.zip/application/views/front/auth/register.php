
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Misho - Pengelola Data Terpercaya</title>
    <link rel="icon" href="<?php echo base_url('assets_home/img/untitle.png') ?>">

    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url() ?>assets_log/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="<?php echo base_url() ?>assets_log/https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo base_url() ?>assets_log/css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="">

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5 col-lg-6 mx-auto">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg">
          <a href="<?php echo base_url('') ?>"><img src="<?php echo base_url('assets_log/img/logo.png') ?>" style="width:10vw;  display: block;
    margin-left: auto;
    margin-right: auto;" alt=""></a>
            <?php echo form_open("auth/register");?>
                        <div class="p-4">
            <?php echo $message;?>
                            <div class="text-center">
                            </div>
                            <form class="user">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0"><label>Nama</label>
                  <?php echo form_input($name);?>
                                    </div>
                                    <div class="col-sm-6">
                  <label>Username</label>
                <?php echo form_input($username);?>
                                    </div>
                                </div>
                                <div class="form-group">
                <label>Email</label>
                <?php echo form_input($email);?>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                  <label>Password</label>
                <?php echo form_password($password);?>
                                    </div>
                                    <div class="col-sm-6">
                  <label>Konfirmasi Password</label>
                <?php echo form_password($password_confirm);?>
                                    </div>
                                </div>
                <div class="form-group" align="middle">
              <button type="submit" class="btn btn-primary" style="background-color:#0ba4f2;padding:0.2rem 3rem 0.2rem 3rem; border-radius:18px;">Register</button>
            </div>
                                <hr>
                                <a href="index.html" class="btn btn-google btn-user btn-block">
                                    <i class="fab fa-google fa-fw"></i> Register with Google
                                </a>
                                <a href="index.html" class="btn btn-facebook btn-user btn-block">
                                    <i class="fab fa-facebook-f fa-fw"></i> Register with Facebook
                                </a>
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="#!" style="color:#0ba4f2;">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <hr class="small" href="login.html"style="color:#0ba4f2;">Already have an account? <a href="<?php echo base_url('admin/auth/login') ?>">Login!</a></hr>
                            </div>
                        </div>
            <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>assets_log/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>assets_log/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>assets_log/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets_log/js/sb-admin-2.min.js"></script>

</body>

</html>