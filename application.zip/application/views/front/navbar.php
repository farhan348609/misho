
<body>

<!-- Header Section Start -->
<header id="home" class="hero-area-2">    
  <div class="overlay"></div>
  <nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
    <div class="container">
      <a href="<?php echo base_url('') ?>" class="navbar-brand"><img src="<?php echo base_url('assets_home/img/logo.png') ?>" width="110vw" height="70vh" alt=""></a>  
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <i class="lni-menu"></i>
      </button>
      <div class="collapse navbar-collapse " id="navbarCollapse">
        <ul class="navbar-nav mr-auto w-100 justify-content-end ">
          <li class="nav-item">
            <a class="nav-link page-scroll" href="<?php echo base_url('') ?>">Home</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link page-scroll" href="#!">Features</a>
          </li>  
          <li class="nav-item">
            <a class="nav-link page-scroll" href="#!">About Us</a>
          </li>                            
          <li class="nav-item">
            <a class="nav-link page-scroll" href="#!">Support</a>
          </li> 
          <li class="nav-item ">
            <a class="nav-link page-scroll" style="border: 2px solid #0ba4f2; border-radius: 15px; padding:0.1rem 2rem 0.1rem 2rem;" href="<?php echo base_url('admin/auth/login') ?>">Login</a>
          </li> 
          <li class="nav-item">
            <a class="nav-link page-scroll"style="border: 2px solid #0ba4f2; border-radius: 15px; padding:0.1rem 2rem 0.1rem 2rem;"  href="<?php echo base_url('auth/register') ?>">Sign Up</a>
          </li> 
        </ul>
      </div>
    </div>
  </nav>  
  <div class="container">      
    <div class="row space-100">
      <div class="col-lg-7 col-md-12 col-xs-12">
        <div class="contents">
          <h2 class="head-title">Misho Solusi Bisnis <br> Online Kamu ...</h2>
          <p>Dengan fitur Misho, Kamu dengan cepat dapat membagikan produk
            berupa barang belanjaan kepada pelanggan yang berupa link yang
            berisi form pemesanan yang dilengkapi dengan fitur yang sangat
            efektif dan efisien. Dimana ini akan dapat memudahkan bisnis online anda. <br><br>
            
            Jadi ditunggu apa lagi? Yuk mari di coba fitur Misho sekarang!</p>
          <div class="header-button">
            <a href="#" class="btn btn-border-filled" style="color: white; background-color:#0ba4f2 ;">Pelajari</a>
          </div>
        </div>
      </div>
      <div class="col-lg-5 col-md-12 col-xs-12" style="background-image: url(img/ima.png); background-repeat: no-repeat; background-size: 150%;">
        <div class="intro-img">
          <img src="<?php echo base_url('assets_home/img/undraw_Data_trends_re_2cdy (1).svg') ?>" alt="">
        </div>            
      </div>
    </div> 
  </div>             
</header>
<!-- Header Section End --> 

<!-- features Section Start -->
<div id="app-features" class="section">
  <div class="container">
    <div class="section-header">      
      <h2 class="section-title wow fadeIn" data-wow-delay="0.2s">Amazing Features</h2>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-12 col-xs-12">
        <div class="content-left text-right">
          <div class="box-item left">
            <span class="icon">
              <i class="fas fa-tasks"></i>
            </span>
            <div class="text">
              <h4>Pendataan Produk</h4>
              <p>Perhitungan jumlah dan jenis barang.</p>
            </div>
          </div>
          <div class="box-item left">
            <span class="icon">
              <i class="fas fa-cogs"></i>
            </span>
            <div class="text">
              <h4>Web Akses</h4>
              <p>Pengelolaan web yang mudah</p>
            </div>
          </div>
          <div class="box-item left">
            <span class="icon">
              <i class="fas fa-chart-line"></i>
            </span>
            <div class="text">
              <h4>Analisis Pembelian</h4>
              <p>Memproses data pembelian menjadi informasi.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-12 col-xs-12">
        <div class="show-box">
          <img src="<?php echo base_url('assets_home/img/Capture.JPG')?>" alt="">
        </div>
      </div>
      <div class="col-lg-4 col-md-12 col-xs-12">
        <div class="content-right text-left">
          <div class="box-item right">
            <span class="icon">
              <i class="fas fa-truck-moving"></i>
            </span>
            <div class="text">
              <h4>Pengiriman</h4>
              <p>Membantu dalam proses pengiriman.</p>
            </div>
          </div>
          <div class="box-item right">
            <span class="icon">
              <i class="far fa-building"></i>
            </span>
            <div class="text">
              <h4>Dasbor</h4>
              <p>Liat ringkasan kinerja online shop kamu dengan lebih cepat.</p>
            </div>
          </div>
          <div class="box-item right">
            <span class="icon">
              <i class="far fa-id-badge"></i>
            </span>
            <div class="text">
              <h4>Kontak</h4>
              <p>Catat semua kontak pelanggan, supplier, dan pegawai kamu.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- features Section End -->


<!-- Awesome Screens Section Start -->
<section id="screenshots" class="screens-shot section">
  <div class="container">
    <div class="section-header">         
      <h2 class="section-title">Special Service</h2>
    </div>
    <div class="row">
      <div class="touch-slider owl-carousel">
        <div class="item">
          <div class="screenshot-thumb">
            <img class="img-fluid" src="<?php echo base_url('assets_home/img/screenshot/service_center.jpg') ?>" alt="">
          </div>
        </div>
        <div class="item">
          <div class="screenshot-thumb">
            <img class="img-fluid" src="<?php echo base_url('assets_home/img/screenshot/location.jpg') ?>" alt="">
          </div>
        </div>
        <div class="item">
          <div class="screenshot-thumb">
            <img class="img-fluid" src="<?php echo base_url('assets_home/img/screenshot/securee.jpg') ?>" alt="">
          </div>
        </div>
        <div class="item">
          <div class="screenshot-thumb">
            <img class="img-fluid" src="<?php echo base_url('assets_home/img/screenshot/chatt.jpg') ?>" alt="">
          </div>
        </div>
        <div class="item">
          <div class="screenshot-thumb">
            <img class="img-fluid" src="<?php echo base_url('assets_home/img/screenshot/userfriendly.jpg') ?>" alt="">
          </div>
        </div>
        <div class="item">
          <div class="screenshot-thumb">
            <img class="img-fluid" src="<?php echo base_url('assets_home/img/screenshot/statistik.jpg') ?>" alt="">
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Awesome Screens Section End -->  

<!-- Testimonial Section Start -->
<section id="testimonial" class="section">
  <div class="container">
    <div class="section-header">         
      <h2 class="section-title">Clients Who Loved Us</h2>
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">
        <div id="testimonials" class="touch-slider owl-carousel">
          <div class="item">
            <div class="testimonial-item">
              <div class="author">
                <div class="img-thumb">
                  <img src="<?php echo base_url('assets_home/img/testimonial/p1.png') ?>" alt="">
                </div>
              </div>
              <div class="content-inner">
                <p class="description"> " Dengan adanya misho ini sangat
                  membantu saya dalam mencatat
                  dari penjualan ".</p>
                <div class="author-info">
                  <h2><a href="#">Paang</a></h2>
                  <span>Dropshipper</span>
                </div>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="testimonial-item">
              <div class="author">
                <div class="img-thumb">
                <img src="<?php echo base_url('assets_home/img/testimonial/p2.png') ?>" alt="">
                </div>
              </div>
              <div class="content-inner">
                <p class="description">"Terimakasih Misho sudah menjadikan saya untuk disiplin dalam mencatat keuangan".</p>
                <div class="author-info">
                  <h2><a href="#">Bella</a></h2>
                  <span>Reseller</span>
                </div>
              </div>
            </div>
          </div>
</section>
<!-- Testimonial Section End -->  

<!-- Clients Section -->
<div id="clients" class="section">
  <!-- Container Ends -->
  <div class="container">
    <!-- Row and Scroller Wrapper Starts -->
    <div class="row" id="clients-scroller">
      <div class="client-item-wrapper">
        <img src="<?php echo base_url('assets_home/img/clients/dana.jpg') ?>" alt="">
      </div>
      <div class="client-item-wrapper">
        <img src="<?php echo base_url('assets_home/img/clients/ovo.jpg') ?>" alt="">
      </div>
      <div class="client-item-wrapper">
        <img src="<?php echo base_url('assets_home/img/clients/jnt.jpg') ?>" alt="">
      </div>
      <div class="client-item-wrapper">
        <img src="<?php echo base_url('assets_home/img/clients/jne.jpg') ?>" alt="">
      </div>
      <div class="client-item-wrapper">
        <img src="<?php echo base_url('assets_home/img/clients/sicepat.jpg') ?>" alt="">
      </div>
      <div class="client-item-wrapper">
        <img src="<?php echo base_url('assets_home/img/clients/shopee.jpg') ?>" alt="">
      </div>
      <div class="client-item-wrapper">
        <img src="<?php echo base_url('assets_home/img/clients/bukalapak.jpg') ?>" alt="">
      </div>
      <div class="client-item-wrapper">
        <img src="<?php echo base_url('assets_home/img/clients/tokopedia.jpg') ?>" alt="">
      </div>
    </div>
  </div>
</div>
<!-- Client Section End --> 

<!-- Start Pricing Table Section -->
<div id="pricing" class="section pricing-section">
  <div class="container">
    <div class="section-header">        
      <h2 class="section-title">Our Pricing Plan</h2>
    </div>

    <div class="row pricing-tables">
      <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="pricing-table wow fadeInLeft" data-wow-delay="0.2s">
          <div class="pricing-details">
            <div class="icon">
              <i class="lni-rocket"></i>
            </div>
            <h2>Free</h2>
            <ul>
              <li>Penjualan Produk</li>
              <li>Perhitungan Stok
              </li>
              <li>Cek Ongkos Kirim & Resi
              </li>
              <li>Laporan Keuangan
              </li>
              <li>Data Produk < 30</li>
              <li>Order Per Bulan < 100</li>
            </ul>
            <div class="price">0IDR<span>/mo</span></div>
          </div>
          <div class="plan-button">
            <a href="#" class="btn btn-border">Get Started</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="pricing-table pricing-active">
          <div class="pricing-details">
            <div class="icon">
              <i class="lni-drop"></i>
            </div>
            <h2>Standard</h2>
            <ul>
              <li>Point Of Sales (POS)</li>
              <li>Data Produk < 500</li>
              <li>Order Per Bulan < 1000</li>
              <li>Range Periode Laporan: 3 Bulan</li>
              <li>Premium Features</li>
              <li>Pengguna: 3 Akun</li>
            </ul>
            <div class="price">39.999IDR<span>/mo</span></div>
          </div>
          <div class="plan-button">
            <a href="#" class="btn btn-border">Get Started</a>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-xs-12">
        <div class="pricing-table">
          <div class="pricing-details">
            <div class="icon">
              <i class="lni-briefcase"></i>
            </div>
            <h2>Business</h2>
            <ul>
              <li>Multi Gudang</li>
              <li>Fitur Bill of Material (BOM) & Assembly</li>
              <li>Intergrasi Warehouse Management System (WMS)</li>
              <li>Sales and Marketing Dashbaord</li>
              <li>Data Produk Unlimited</li>
              <li>Order Per Bulan Unlimited</li>
            </ul>
            <div class="price">199.999IDR<span>/mo</span></div>
          </div>
          <div class="plan-button">
            <a href="#" class="btn btn-border">Get Started</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<!-- End Pricing Table Section -->

<!-- download Section Start -->
<section id="download">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-xs-12">            
        <div class="download-thumb wow fadeInLeft" data-wow-delay="0.2s">
          <img class="img-fluid" src="<?php echo base_url('assets_home/img/play.png') ?>" alt="">
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-xs-12">
        <div class="download-wrapper wow fadeInRight" data-wow-delay="0.2s">
          <div>
            <div class="download-text">
              <h4>Download Our App From Store</h4>
              <p>Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive.</p>
            </div>
            <a href="#" class="btn btn-common btn-effect"><i class="lni-android"></i> From PlayStore<br></a>
            <a href="#" class="btn btn-apple"><i class="lni-apple"></i> From AppStore<br></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- download Section Start -->

<!-- Blog Section -->
<section id="blog" class="section">
  <!-- Container Starts -->
  <div class="container">
     <div class="section-header">         
      <h2 class="section-title">Blog</h2>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-6 col-xs-12 blog-item">
        <!-- Blog Item Starts -->
        <div class="blog-item-wrapper">
          <div class="blog-item-img">
            <a href="single-post.html">
              <img src="<?php echo base_url('assets_home/img/blog/misho.png') ?>" width="50vw" height="250vh" alt="">
            </a>   
            <div class="author-img">
              <img src="<?php echo base_url('assets_home/img/testimonial/p1.png') ?>" alt="">
            </div>             
          </div>
          <div class="blog-item-text"> 
            <h3><a href="single-post.html">Misho menjadi salah satu startup bergengsi</a></h3>
            <div class="author">
              <span class="name"><a href="#">Posted by Paang</a></span>
              <span class="date float-right">11 Februari, 2021</span>
            </div>
          </div>
        </div>
        <!-- Blog Item Wrapper Ends-->
      </div>

      <div class="col-lg-4 col-md-6 col-xs-12 blog-item">
        <!-- Blog Item Starts -->
        <div class="blog-item-wrapper">
          <div class="blog-item-img">
            <a href="single-post.html">
              <img src="<?php echo base_url('assets_home/img/blog/surface-V_JGp9lnojw-unsplash.jpg') ?>" width="50vw" height="250vh" alt="">
            </a>   
            <div class="author-img">
              <img src="<?php echo base_url('assets_home/img/testimonial/p2.png') ?>" alt="">
            </div>             
          </div>
          <div class="blog-item-text"> 
            <h3><a href="single-post.html">Trik memenangkan SEO untuk website</a></h3>
            <div class="author">
              <span class="name"><a href="#">Posted by Bella</a></span>
              <span class="date float-right">10 April, 2021</span>
            </div>
          </div>
        </div>
        <!-- Blog Item Wrapper Ends-->
      </div>

      <div class="col-lg-4 col-md-6 col-xs-12 blog-item">
        <!-- Blog Item Starts -->
        <div class="blog-item-wrapper">
          <div class="blog-item-img">
            <a href="single-post.html">
              <img src="<?php echo base_url('assets_home/img/blog/xps-ocAuPlfZXEc-unsplash.jpg') ?>" width="50vw" height="250vh" alt="">
            </a>   
            <div class="author-img">
              <img src="<?php echo base_url('assets_home/img/testimonial/p1.png') ?>" alt="">
            </div>             
          </div>
          <div class="blog-item-text"> 
            <h3><a href="single-post.html">10 Rekomendasi startup terbaik !!!</a></h3>
            <div class="author">
              <span class="name"><a href="#">Posted by Admin</a></span>
              <span class="date float-right">17 September, 2020</span>
            </div>
          </div>
        </div>
        <!-- Blog Item Wrapper Ends-->
      </div>
    </div>
  </div>
</section>
<!-- blog Section End -->
