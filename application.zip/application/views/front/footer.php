    <!-- Footer Section Start -->
    <footer>
      <!-- Footer Area Start -->
      <section class="footer-Content">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-mb-12">
              <img src="<?php echo base_url('assets_home/img/logo.png') ?>"  width="110vw" height="70vh" alt="">
              <div class="textwidget">
                <p>Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive.</p>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-mb-12">
              <div class="widget">
                <h3 class="block-title">Create a Free Account</h3>
                <ul class="menu">
                  <li><a href="#">Sign In</a></li>
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Pricing</a></li>
                  <li><a href="#">Jobs</a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-mb-12">
              <div class="widget">
                <h3 class="block-title">Resource</h3>
                <ul class="menu">
                  <li><a href="#">Comunnity</a></li>
                  <li><a href="#">Become a Partner</a></li>
                  <li><a href="#">Our Technology</a></li>
                  <li><a href="#">Documentation</a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-mb-12">
              <div class="widget">
                <h3 class="block-title">Support</h3>
                <ul class="menu">
                  <li><a href="#">Terms & Condition</a></li>
                  <li><a href="#">Contact Us</a></li>
                  <li><a href="#">Privacy Policy</a></li>
                  <li><a href="#">Help</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!-- Copyright Start  -->
        <div class="copyright">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="site-info float-left">
                  <p>&copy; 2020 - Designed by Misho</p>
                </div>              
                <div class="float-right">  
                  <ul class="footer-social">
                    <li><a class="facebook" href="#"><i class="lni-facebook-filled"></i></a></li>
                    <li><a class="twitter" href="#"><i class="lni-twitter-filled"></i></a></li>
                    <li><a class="linkedin" href="#"><i class="lni-linkedin-fill"></i></a></li>
                    <li><a class="google-plus" href="#"><i class="lni-google-plus"></i></a></li>
                  </ul> 
                </div>
              </div>
            </div>
          </div>
        </div>
      <!-- Copyright End -->
      </section>
      <!-- Footer area End -->
      
    </footer>
    <!-- Footer Section End --> 

    <!-- Go To Top Link -->
    <a href="#" class="back-to-top">
      <i class="lni-chevron-up"></i>
    </a> 

    <!-- Preloader -->
    <div id="preloader">
      <div class="loader" id="loader-1"></div>
    </div>
    <!-- End Preloader -->

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="<?php echo base_url() ?>assets_home/js/jquery-min.js"></script>
    <script src="<?php echo base_url() ?>assets_home/js/popper.min.js"></script>
    <script src="<?php echo base_url() ?>assets_home/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>assets_home/js/owl.carousel.js"></script> 
    <script src="<?php echo base_url() ?>assets_home/js/jquery.mixitup.js"></script>       
    <script src="<?php echo base_url() ?>assets_home/js/jquery.nav.js"></script>    
    <script src="<?php echo base_url() ?>assets_home/js/scrolling-nav.js"></script>    
    <script src="<?php echo base_url() ?>assets_home/js/jquery.easing.min.js"></script>     
    <script src="<?php echo base_url() ?>assets_home/js/wow.js"></script>   
    <script src="<?php echo base_url() ?>assets_home/js/jquery.counterup.min.js"></script>     
    <script src="<?php echo base_url() ?>assets_home/js/nivo-lightbox.js"></script>     
    <script src="<?php echo base_url() ?>assets_home/js/jquery.magnific-popup.min.js"></script>     
    <script src="<?php echo base_url() ?>assets_home/js/waypoints.min.js"></script>      
    <script src="<?php echo base_url() ?>assets_home/js/form-validator.min.js"></script>
    <script src="<?php echo base_url() ?>assets_home/js/contact-form-script.js"></script>   
    <script src="<?php echo base_url() ?>assets_home/js/main.js"></script>
    <script src="https://kit.fontawesome.com/04b62e6f1b.js" crossorigin="anonymous"></script>
  </body>