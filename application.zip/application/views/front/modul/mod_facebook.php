<div class="container">
  <div id="fb-root"></div>
  <script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=1079046148857661";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));</script>

  <div class="fb-page" data-href="https://www.facebook.com/Arena-PHP-1626283007671661/?ref=bookmarks" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/Arena-PHP-1626283007671661/?ref=bookmarks" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/Arena-PHP-1626283007671661/?ref=bookmarks">Arena PHP</a></blockquote></div>
</div>
